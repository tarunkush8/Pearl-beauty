<?php
session_start();
$IsLoggedIn= isset($_SESSION["UID"]);
 include('assets/phpscript/FormatedOutput.php');
    include('assets/Database/DBMySql.php');$db=new DBMySql;
    $Brand="";$PID=0;
    if(isset($_GET["Brand"])) $Brand=$_GET["Brand"];
    if(isset($_GET["PID"])) $PID=$_GET["PID"];

    $sql="select * from `products` where `Brand` ='".$Brand."' and PID<>".$PID;

    $Products = $db->GetResult($sql);


?>

<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>PearBeauty_E_Commerce_Site</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css" />
    <script src="assets/js/myjs.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="assets/css/Sidebar-Menu-1.css" />
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
    <script src="assets/alertifyjs/alertify.min.js "></script>
    <link rel="stylesheet" href="assets/alertifyjs/css/alertify.min.css" />
    <link rel="stylesheet" href="assets/alertifyjs/css/themes/default.min.css" />

    <script src="assets/js/angular.min.js"></script>
    <script src="assets/js/angular-sanitize.min.js"></script>
    <script>
        var app = angular.module('myApp', []);
        app.controller('customersCtrl', function ($scope, $http, $location) {
            $scope.BillAmount = 0;
            $scope.params = QueryStringToJSON();

            $scope.Cart = [];
            $scope.CartPID = [];
            $scope.SelectedProducts = [];
            $scope.Category = null;


            console.log($scope.params);

            if ($scope.params.PID != null) {
                $http.get("assets/api/getproducts.php?PID=" + $scope.params.PID).then(function (response) {
                    $scope.Product = response.data.Data[0];
                            console.log($scope.Product);
                });
            }
            
            if (localStorage.getItem('Cart') != null) {

                $scope.Cart = JSON.parse(localStorage.getItem('Cart'));
                for (var i = 0; i < $scope.Cart.length; i++) {
                    $scope.CartPID.push($scope.Cart[i].PID);
                }
                console.log($scope.CartPID);
                
            }
                

            $scope.AddToCart = function (Product) {

                for (var i = 0; i < $scope.Cart.length; i++) {
                    if ($scope.Cart[i].PID == Product.PID) {
                        $scope.Cart.splice(i, 1);
                        $scope.CartPID.splice($scope.CartPID.indexOf(Product.PID),1);
                        localStorage.setItem('Cart', JSON.stringify($scope.Cart));
                        return;
                    }
                }
                $scope.Cart.push(Product);
                $scope.CartPID.push($scope.Product.PID);
                localStorage.setItem('Cart', JSON.stringify($scope.Cart));
                console.log(9999, $scope.Cart);
            }
            $scope.CheckOut = function () {
               
               localStorage.setItem('Products', JSON.stringify($scope.Cart));
               localStorage.setItem('Cart', JSON.stringify($scope.Cart));
               location.assign('./pointofsale.php');
           } 


        });

    </script>
</head>

<body ng-app="myApp" ng-controller="customersCtrl" style="background: rgb(255,238,238);">
    <?php include('menu.php');?>
    <div class="container" style="margin-top: 11px;">
        <h4 class="text-secondary">Product</h4>
    </div>
    <hr />
    <div class="container">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="row" style="margin-bottom: 10px;">
                    <div class="col">
                        <h4>{{Product.ProductName}}</h4>
                    </div>
                    <div class="col text-right">
                        <div class="btn-group" role="group">
                            <button class="btn btn-success" ng-show="!CartPID.includes(Product.PID)" ng-click="AddToCart(Product)" type="button">Add to Cart</button>
                            <button class="btn btn-danger" ng-show="CartPID.includes(Product.PID)" ng-click="AddToCart(Product)" type="button">Remove from Cart</button>
                        </div>
                    </div>
                    <div ng-show="Cart.length>0"  class="col">
                        <?php if( !$IsLoggedIn){  ?> 
                        <a href="login.php" class="btn btn-danger" >Login to Proceed</a>
                        <button disabled class="btn btn-primary" >Check out</button>
                        <?php }else { ?> 
                        <button ng-click="CheckOut()" class="btn btn-primary" >Check out</button>
                        <?php } ?>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td rowspan="5" style="width: 342px;">
                                    <img class="img-fluid border rounded shadow-sm" src="{{'assets/img/products/'+Product.PID+'.jpg'}}" style="margin-bottom: 10px;width: 300px;" />
                                </td>
                                <td>
                                    <h6 class="text-muted mb-2">
                                        Product Name : 
                                        <strong>{{Product.ProductName}}</strong>/-
                                    </h6>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <h6 class="text-muted mb-2">
                                        Price :
                                        <strong>{{Product.Price}}</strong>
                                    </h6>
                                </td>
                            
                            <tr>
                                <td>
                                    <h6 class="text-muted mb-2">
                                        Category:
                                        <strong>{{Product.Category}}</strong>
                                    </h6>
                                </td>
                            </tr>
                           
                            <tr>
                                <td>
                                    <h6 class="text-muted mb-2">
                                        Sub Category:
                                        <strong>{{Product.SubCategory}}</strong>
                                    </h6>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <p>
                                        Product Details&nbsp;Product Details&nbsp;Product Details&nbsp;Product Details
                                        <br />
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="container" style="margin-top: 20px;">
        <div class="card shadow-sm">
            <div class="card-body">
                <h4 class="text-secondary">Recommendation</h4>
                <hr />
                <div class="row">
                    <?php
                    if($Products) while($row = $Products->fetch_assoc())
                {
                    ?>
                    <div class="col-md-6 col-lg-4 col-xl-4 mb-2">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <img class="img-fluid border rounded shadow-sm" src="assets/img/Products/<?php echo $row["PID"]; ?>.jpg"
                                    style="margin-bottom: 10px;width: 227px;" />
                                <h4 class="card-title"><?php echo $row["ProductName"]; ?></h4>
                                <h6 class="text-muted card-subtitle mb-2">
                                    Price :
                                    <strong><?php echo $row["Price"]; ?></strong>/-
                                </h6>
                                <div class="btn-group" role="group">
                                    <a class="btn btn-success" href="productInfo.php?PID=<?php echo $row["PID"]; ?>&SubCategory=<?php echo $row["SubCategory"]; ?>">View</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>
</body>

</html>