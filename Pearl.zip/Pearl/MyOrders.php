<?php

session_start();
include('assets/Database/DBMySql.php'); $db=new DBMySql;
include('assets/phpscript/FormatedOutput.php');
$keyword="";
$UID=0;
if(($_SESSION["UserType"]=='Admin')){ header("location: login.php");return; }
$UID=$_SESSION["UID"];


if(isset($_GET["OID"]) && isset($_GET["Status"]))
{
    $sql="UPDATE orders SET `Status`='".$_GET["Status"]."' WHERE OID=".$_GET["OID"];
    $db->NonQuery($sql);
}

//

$Orders=array();
$con=$db->GetActiveConnection();
$result= $db->GetResultOnConnection("select * from orders where UID=".$UID." order by OID desc ",$con);

if($result)while( $row = $result->fetch_assoc()){ $Orders[] = $row; }

for ($n=0;$n<count($Orders);$n++)//
{
    $result = $db->GetResultOnConnection("select * from orderinfo where OrderNumber=".$Orders[$n]['OrderNumber'],$con);
    $Products=array();
    if($result)while( $row = $result->fetch_assoc()){ $Products[] = $row; }
    $Orders[$n]['Products']=$Products;
}
$con->close();
//   header("location: customerlogin.php");return;


?>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>Pearl Beauty</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css" />
    <link rel="stylesheet" href="assets/css/cards.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
</head>

<body style="background: rgb(242,242,242);">
    <?php include("menu.php");?>

    <div class="container d-flex" style="margin-top: 20px;">
        <h4 class="text-secondary d-xl-flex flex-fill align-items-xl-center">My Orders</h4>
    </div>
    <hr />
    <div class="container">

        <?php if($Orders) foreach($Orders as $Order)
                  {

        ?>

        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col d-xl-flex align-items-xl-center">
                        <h5 class="text-secondary flex-fill">
                            Order Number - #<?php echo $Order['OrderNumber']; ?>
                        </h5>
                        <h5 class="text-success">
                            Bill Amount - <?php echo $Order['BillAmount'] ?>
                        </h5>
                    </div>
                </div>
                <div class="row" style="margin-top: 11px;">
                    <div class="col d-xl-flex align-items-xl-center">
                        <h6 class="flex-fill">
                            Customer - <?php echo $Order['CustomerName'] ?> - <?php echo $Order['CustomerMobile'] ?>
                        </h6>
                    </div>
                </div>
                <hr />
                <div class="table-responsive bg-white border rounded shadow-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr class="table-danger">
                                <th style="width: 54px;">Sn.</th>
                                <th>ProductName</th>
                                <th style="width: 247px;">Price</th>
                                <th style="width: 188px;">Quantity</th>
                                <th style="width: 85px;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1;
                                  if( $Order['Products'])foreach($Order['Products'] as $Product)
                                      {
                            ?>
                            <tr>
                                <td>
                                    <?php echo $i++; ?>
                                </td>
                                <td style="width: 133px;">
                                    <?php echo $Product['ProductName']; ?>
                                </td>
                                <td>
                                    <?php echo $Product['Price']; ?>
                                </td>
                                <td>
                                    <?php echo $Product['Quantity']; ?>
                                </td>
                                <td>
                                    <?php echo ($Product['Price'] * $Product['Quantity']); ?>
                                </td>
                            </tr>
                            <?php } ?>
                            <tr><td colspan="3">
                            <?php if($Order['Status']=='Pending'){ ?>
                                <a class="btn btn-danger" href="MyOrders.php?Status=Cancelled&OID=<?php echo ($Order['OID']); ?>">Cancel Order</a>
                                <?php }else{ ?>
                                <button disabled class="btn btn-danger">Order Cancelled</button>    
                                    <?php }?><?php ?>
                                
                                </td>
                             </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php } ?>


    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>